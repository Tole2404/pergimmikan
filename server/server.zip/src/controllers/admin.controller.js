const jwt = require("jsonwebtoken");
const AdminModel = require("../models/admin.model");
const ApiError = require("../utils/apiError");

class AdminController {
  async login(req, res, next) {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        throw new ApiError(400, "Username and password are required");
      }

      const admin = await AdminModel.findByUsername(username);
      if (!admin) {
        throw new ApiError(401, "Invalid credentials");
      }

      if (admin.status === "inactive") {
        throw new ApiError(401, "Account is inactive");
      }

      const isValidPassword = await AdminModel.validatePassword(password, admin.password);
      if (!isValidPassword) {
        throw new ApiError(401, "Invalid credentials");
      }

      const token = jwt.sign(
        {
          id: admin.id,
          username: admin.username,
          role: admin.role,
        },
        process.env.JWT_SECRET,
        { expiresIn: "24h" }
      );

      delete admin.password;

      res.json({
        message: "Login successful",
        token,
        admin: {
          id: admin.id,
          username: admin.username,
          nama_lengkap: admin.nama_lengkap,
          email: admin.email,
          role: admin.role,
        },
      });
    } catch (error) {
      next(error);
    }
  }

  async logout(req, res) {
    res.json({ message: "Logout successful" });
  }

  async getProfile(req, res) {
    const admin = await AdminModel.findById(req.admin.id);
    delete admin.password;
    res.json(admin);
  }

  async updateProfile(req, res, next) {
    try {
      const { nama_lengkap, email } = req.body;
      const adminId = req.admin.id;

      const success = await AdminModel.updateAdmin(adminId, {
        nama_lengkap,
        email,
      });

      if (!success) {
        throw new ApiError(404, "Admin not found");
      }

      res.json({ message: "Profile updated successfully" });
    } catch (error) {
      next(error);
    }
  }

  async changePassword(req, res, next) {
    try {
      const { currentPassword, newPassword } = req.body;
      const adminId = req.admin.id;

      const admin = await AdminModel.findById(adminId);
      if (!admin) {
        throw new ApiError(404, "Admin not found");
      }

      const isValidPassword = await AdminModel.validatePassword(currentPassword, admin.password);
      if (!isValidPassword) {
        throw new ApiError(401, "Current password is incorrect");
      }

      await AdminModel.changePassword(adminId, newPassword);

      res.json({ message: "Password updated successfully" });
    } catch (error) {
      next(error);
    }
  }

  async getAllUsers(req, res) {
    res.json({ message: "Get all users" });
  }

  async createUser(req, res) {
    res.json({ message: "Create user" });
  }

  async getUserById(req, res) {
    res.json({ message: "Get user by id" });
  }

  async updateUser(req, res) {
    res.json({ message: "Update user" });
  }

  async deleteUser(req, res) {
    res.json({ message: "Delete user" });
  }

  async updateUserStatus(req, res) {
    res.json({ message: "Update user status" });
  }

  async getAllContent(req, res) {
    res.json({ message: "Get all content" });
  }

  async createContent(req, res) {
    res.json({ message: "Create content" });
  }

  async getContentById(req, res) {
    res.json({ message: "Get content by id" });
  }

  async updateContent(req, res) {
    res.json({ message: "Update content" });
  }

  async deleteContent(req, res) {
    res.json({ message: "Delete content" });
  }

  async updateContentStatus(req, res) {
    res.json({ message: "Update content status" });
  }
}

module.exports = new AdminController();
