// Featured Journeys API documentation has been removed as requested
